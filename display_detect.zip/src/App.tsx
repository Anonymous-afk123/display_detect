import React, { useState } from 'react'
import ImageUpload from './components/ImageUpload'
import DetectionResult from './components/DetectionResult'
import Statistics from './components/Statistics'
import SystemInfo from './components/SystemInfo'

function App() {
  const [activeTab, setActiveTab] = useState('detect')
  const [detectionResult, setDetectionResult] = useState<any>(null)
  const [loading, setLoading] = useState(false)

  const handleDetection = (result: any) => {
    setDetectionResult(result)
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-100 to-gray-200 dark:from-gray-900 dark:to-gray-800">
      <div className="container mx-auto px-4 py-8 max-w-6xl">
        {/* 头部 */}
        <header className="mb-8 text-center">
          <h1 className="text-4xl font-bold text-gray-800 dark:text-white mb-2">
            显示屏智能检测与评估系统
          </h1>
          <p className="text-lg text-gray-600 dark:text-gray-300">
            智能识别坏点、划痕、漏光、瑕疵
          </p>
        </header>

        {/* 标签页导航 */}
        <div className="flex justify-center mb-8 bg-white dark:bg-gray-800 rounded-lg shadow-md p-1">
          <button
            className={`px-6 py-2 rounded-md font-medium ${activeTab === 'detect' ? 'bg-primary text-white' : 'text-gray-600 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-700'}`}
            onClick={() => setActiveTab('detect')}
          >
            图像检测
          </button>
          <button
            className={`px-6 py-2 rounded-md font-medium ${activeTab === 'statistics' ? 'bg-primary text-white' : 'text-gray-600 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-700'}`}
            onClick={() => setActiveTab('statistics')}
          >
            统计信息
          </button>
          <button
            className={`px-6 py-2 rounded-md font-medium ${activeTab === 'system' ? 'bg-primary text-white' : 'text-gray-600 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-700'}`}
            onClick={() => setActiveTab('system')}
          >
            系统信息
          </button>
        </div>

        {/* 内容区域 */}
        <div className="bg-white dark:bg-gray-800 rounded-xl shadow-lg p-6">
          {activeTab === 'detect' && (
            <div className="space-y-6">
              <ImageUpload onDetection={handleDetection} setLoading={setLoading} />
              {loading && (
                <div className="flex justify-center items-center py-12">
                  <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary"></div>
                </div>
              )}
              {detectionResult && (
                <DetectionResult result={detectionResult} />
              )}
            </div>
          )}

          {activeTab === 'statistics' && (
            <Statistics />
          )}

          {activeTab === 'system' && (
            <SystemInfo />
          )}
        </div>

        {/* 底部 */}
        <footer className="mt-8 text-center text-gray-600 dark:text-gray-400 text-sm">
          <p>© 2026 显示屏智能检测与评估系统 | 基于 YOLOv8 模型</p>
        </footer>
      </div>
    </div>
  )
}

export default App
