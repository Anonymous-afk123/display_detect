import React, { useState } from 'react'
import axios from 'axios'

interface ImageUploadProps {
  onDetection: (result: any) => void
  setLoading: (loading: boolean) => void
}

const ImageUpload: React.FC<ImageUploadProps> = ({ onDetection, setLoading }) => {
  const [selectedFile, setSelectedFile] = useState<File | null>(null)
  const [confidence, setConfidence] = useState<number>(0.25)
  const [preview, setPreview] = useState<string | null>(null)

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (file) {
      setSelectedFile(file)
      const reader = new FileReader()
      reader.onloadend = () => {
        setPreview(reader.result as string)
      }
      reader.readAsDataURL(file)
    }
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!selectedFile) return

    setLoading(true)
    try {
      const formData = new FormData()
      formData.append('file', selectedFile)
      formData.append('confidence', confidence.toString())

      const response = await axios.post('/api/detect', formData, {
        headers: {
          'Content-Type': 'multipart/form-data'
        }
      })

      onDetection(response.data)
    } catch (error) {
      console.error('检测失败:', error)
      alert('检测失败，请重试')
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="space-y-6">
      <form onSubmit={handleSubmit} className="space-y-4">
        <div className="flex flex-col md:flex-row gap-6">
          {/* 图像上传区域 */}
          <div className="flex-1">
            <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
              上传图片
            </label>
            <div className="border-2 border-dashed border-gray-300 dark:border-gray-600 rounded-lg p-6 text-center hover:border-primary transition-colors">
              {preview ? (
                <div className="relative">
                  <img 
                    src={preview} 
                    alt="预览" 
                    className="max-h-64 object-contain mx-auto rounded"
                  />
                  <button
                    type="button"
                    className="absolute top-2 right-2 bg-red-500 text-white rounded-full p-1 hover:bg-red-600"
                    onClick={() => {
                      setSelectedFile(null)
                      setPreview(null)
                    }}
                  >
                    ×
                  </button>
                </div>
              ) : (
                <div>
                  <input
                    type="file"
                    accept="image/*"
                    onChange={handleFileChange}
                    className="hidden"
                    id="file-upload"
                  />
                  <label
                    htmlFor="file-upload"
                    className="cursor-pointer text-primary hover:underline"
                  >
                    点击上传或拖拽文件到此处
                  </label>
                  <p className="text-sm text-gray-500 dark:text-gray-400 mt-2">
                    支持 JPG、PNG、JPEG 格式
                  </p>
                </div>
              )}
            </div>
          </div>

          {/* 置信度设置 */}
          <div className="flex-1 flex flex-col justify-center">
            <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
              置信度阈值: {confidence.toFixed(2)}
            </label>
            <input
              type="range"
              min="0.1"
              max="1.0"
              step="0.05"
              value={confidence}
              onChange={(e) => setConfidence(parseFloat(e.target.value))}
              className="w-full h-2 bg-gray-200 dark:bg-gray-700 rounded-lg appearance-none cursor-pointer"
            />
            <div className="flex justify-between text-xs text-gray-500 dark:text-gray-400 mt-1">
              <span>0.1</span>
              <span>0.5</span>
              <span>1.0</span>
            </div>

            <button
              type="submit"
              disabled={!selectedFile}
              className="mt-6 bg-primary hover:bg-blue-600 text-white font-medium py-2 px-6 rounded-lg transition-colors disabled:bg-gray-300 disabled:cursor-not-allowed"
            >
              开始检测
            </button>
          </div>
        </div>
      </form>
    </div>
  )
}

export default ImageUpload
