import React from 'react'

interface Defect {
  type: string
  confidence: number
  coordinates: number[]
}

interface AnalysisResult {
  num_defects: number
  is_qualified: boolean
  severity: number
  defects: Defect[]
}

interface DetectionResultProps {
  result: {
    annotated_image: string
    analysis_result: AnalysisResult
  }
}

const DetectionResult: React.FC<DetectionResultProps> = ({ result }) => {
  const { annotated_image, analysis_result } = result
  const { num_defects, is_qualified, severity, defects } = analysis_result

  const getSeverityText = (severity: number) => {
    if (severity <= 1) return '轻微'
    if (severity <= 3) return '中度'
    return '严重'
  }

  return (
    <div className="space-y-6 mt-8">
      <h2 className="text-2xl font-bold text-gray-800 dark:text-white">检测结果</h2>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* 标注图像 */}
        <div>
          <h3 className="text-lg font-medium text-gray-700 dark:text-gray-300 mb-2">
            检测结果图像
          </h3>
          <div className="border border-gray-200 dark:border-gray-700 rounded-lg overflow-hidden">
            <img 
              src={annotated_image} 
              alt="检测结果" 
              className="w-full h-auto"
            />
          </div>
        </div>

        {/* 分析结果 */}
        <div>
          <h3 className="text-lg font-medium text-gray-700 dark:text-gray-300 mb-4">
            分析结果
          </h3>
          <div className="space-y-3">
            <div className="flex justify-between items-center p-3 bg-gray-50 dark:bg-gray-700 rounded-lg">
              <span className="text-gray-600 dark:text-gray-300">瑕疵数量:</span>
              <span className="font-semibold text-gray-800 dark:text-white">{num_defects}</span>
            </div>
            <div className="flex justify-between items-center p-3 bg-gray-50 dark:bg-gray-700 rounded-lg">
              <span className="text-gray-600 dark:text-gray-300">检测结果:</span>
              <span className={`font-semibold ${is_qualified ? 'text-green-500' : 'text-red-500'}`}>
                {is_qualified ? '✅ 合格' : '❌ 不合格'}
              </span>
            </div>
            <div className="flex justify-between items-center p-3 bg-gray-50 dark:bg-gray-700 rounded-lg">
              <span className="text-gray-600 dark:text-gray-300">严重程度:</span>
              <span className="font-semibold text-gray-800 dark:text-white">
                {getSeverityText(severity)}
              </span>
            </div>
          </div>
        </div>
      </div>

      {/* 缺陷详情 */}
      {defects.length > 0 && (
        <div className="mt-6">
          <h3 className="text-lg font-medium text-gray-700 dark:text-gray-300 mb-3">
            缺陷详情
          </h3>
          <div className="bg-gray-50 dark:bg-gray-700 rounded-lg p-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
              {defects.map((defect, index) => (
                <div key={index} className="p-3 border border-gray-200 dark:border-gray-600 rounded-lg">
                  <div className="font-medium text-gray-800 dark:text-white">
                    缺陷 {index + 1}
                  </div>
                  <div className="text-sm text-gray-600 dark:text-gray-300">
                    类型: {defect.type}
                  </div>
                  <div className="text-sm text-gray-600 dark:text-gray-300">
                    置信度: {defect.confidence.toFixed(2)}
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}
    </div>
  )
}

export default DetectionResult
