import React, { useState, useEffect } from 'react'
import axios from 'axios'

interface ModelInfo {
  status: string
  model_path: string
  model_name: string
}

const SystemInfo: React.FC = () => {
  const [modelInfo, setModelInfo] = useState<ModelInfo | null>(null)
  const [loading, setLoading] = useState(true)

  const fetchModelInfo = async () => {
    setLoading(true)
    try {
      const response = await axios.get('/api/model-info')
      setModelInfo(response.data)
    } catch (error) {
      console.error('获取模型信息失败:', error)
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => {
    fetchModelInfo()
  }, [])

  if (loading) {
    return (
      <div className="flex justify-center items-center py-12">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary"></div>
      </div>
    )
  }

  return (
    <div className="space-y-6">
      <h2 className="text-2xl font-bold text-gray-800 dark:text-white">系统信息</h2>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* 模型信息 */}
        <div className="bg-gray-50 dark:bg-gray-700 rounded-lg p-6">
          <h3 className="text-lg font-medium text-gray-700 dark:text-gray-300 mb-4">
            模型信息
          </h3>
          <div className="space-y-3">
            <div className="flex justify-between items-center p-3 border-b border-gray-200 dark:border-gray-600">
              <span className="text-gray-600 dark:text-gray-300">模型状态:</span>
              <span className={`font-semibold ${modelInfo?.status === '已加载' ? 'text-green-500' : 'text-red-500'}`}>
                {modelInfo?.status || '未知'}
              </span>
            </div>
            <div className="flex justify-between items-center p-3 border-b border-gray-200 dark:border-gray-600">
              <span className="text-gray-600 dark:text-gray-300">模型路径:</span>
              <span className="font-semibold text-gray-800 dark:text-white text-sm">
                {modelInfo?.model_path || '未知'}
              </span>
            </div>
            <div className="flex justify-between items-center p-3">
              <span className="text-gray-600 dark:text-gray-300">模型名称:</span>
              <span className="font-semibold text-gray-800 dark:text-white">
                {modelInfo?.model_name || '未知'}
              </span>
            </div>
          </div>
          <button
            onClick={fetchModelInfo}
            className="mt-4 bg-primary hover:bg-blue-600 text-white font-medium py-2 px-4 rounded-lg transition-colors"
          >
            刷新模型信息
          </button>
        </div>

        {/* 系统说明 */}
        <div className="bg-gray-50 dark:bg-gray-700 rounded-lg p-6">
          <h3 className="text-lg font-medium text-gray-700 dark:text-gray-300 mb-4">
            系统说明
          </h3>
          <ul className="space-y-2 text-gray-600 dark:text-gray-300">
            <li className="flex items-start">
              <span className="mr-2 text-primary">•</span>
              <span>检测类型：坏点、划痕、漏光、污渍</span>
            </li>
            <li className="flex items-start">
              <span className="mr-2 text-primary">•</span>
              <span>模型：YOLOv8s</span>
            </li>
            <li className="flex items-start">
              <span className="mr-2 text-primary">•</span>
              <span>置信度：可调节，默认为0.25</span>
            </li>
            <li className="flex items-start">
              <span className="mr-2 text-primary">•</span>
              <span>结果保存：自动保存到本地存储</span>
            </li>
            <li className="flex items-start">
              <span className="mr-2 text-primary">•</span>
              <span>API地址：http://localhost:8000/api</span>
            </li>
          </ul>
        </div>
      </div>
    </div>
  )
}

export default SystemInfo
