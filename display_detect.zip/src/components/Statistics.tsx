import React, { useState, useEffect } from 'react'
import axios from 'axios'

interface StatisticsData {
  total_detections: number
  qualified: number
  unqualified: number
  avg_defects: number
}

const Statistics: React.FC = () => {
  const [statistics, setStatistics] = useState<StatisticsData | null>(null)
  const [loading, setLoading] = useState(true)
  const [message, setMessage] = useState<string>('')

  const fetchStatistics = async () => {
    setLoading(true)
    try {
      const response = await axios.get('/api/statistics')
      setStatistics(response.data)
    } catch (error) {
      console.error('获取统计信息失败:', error)
      setMessage('获取统计信息失败')
    } finally {
      setLoading(false)
    }
  }

  const handleClearResults = async () => {
    try {
      const response = await axios.post('/api/clear-results')
      setMessage(response.data.message)
      fetchStatistics()
    } catch (error) {
      console.error('清空结果失败:', error)
      setMessage('清空结果失败')
    }
  }

  useEffect(() => {
    fetchStatistics()
  }, [])

  if (loading) {
    return (
      <div className="flex justify-center items-center py-12">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary"></div>
      </div>
    )
  }

  return (
    <div className="space-y-6">
      <h2 className="text-2xl font-bold text-gray-800 dark:text-white">统计信息</h2>

      {message && (
        <div className="p-3 bg-blue-100 dark:bg-blue-900 text-blue-800 dark:text-blue-200 rounded-lg">
          {message}
        </div>
      )}

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="bg-gray-50 dark:bg-gray-700 rounded-lg p-6">
          <h3 className="text-lg font-medium text-gray-700 dark:text-gray-300 mb-4">
            检测统计
          </h3>
          <div className="space-y-3">
            <div className="flex justify-between items-center p-3 border-b border-gray-200 dark:border-gray-600">
              <span className="text-gray-600 dark:text-gray-300">总检测次数:</span>
              <span className="font-semibold text-gray-800 dark:text-white">
                {statistics?.total_detections || 0}
              </span>
            </div>
            <div className="flex justify-between items-center p-3 border-b border-gray-200 dark:border-gray-600">
              <span className="text-gray-600 dark:text-gray-300">合格数量:</span>
              <span className="font-semibold text-green-500">
                {statistics?.qualified || 0}
              </span>
            </div>
            <div className="flex justify-between items-center p-3 border-b border-gray-200 dark:border-gray-600">
              <span className="text-gray-600 dark:text-gray-300">不合格数量:</span>
              <span className="font-semibold text-red-500">
                {statistics?.unqualified || 0}
              </span>
            </div>
            <div className="flex justify-between items-center p-3">
              <span className="text-gray-600 dark:text-gray-300">平均缺陷数:</span>
              <span className="font-semibold text-gray-800 dark:text-white">
                {(statistics?.avg_defects || 0).toFixed(2)}
              </span>
            </div>
          </div>
        </div>

        <div className="flex flex-col justify-center">
          <h3 className="text-lg font-medium text-gray-700 dark:text-gray-300 mb-4">
            操作
          </h3>
          <button
            onClick={fetchStatistics}
            className="bg-primary hover:bg-blue-600 text-white font-medium py-3 px-6 rounded-lg transition-colors mb-4 w-full"
          >
            刷新统计
          </button>
          <button
            onClick={handleClearResults}
            className="bg-gray-200 hover:bg-gray-300 text-gray-800 font-medium py-3 px-6 rounded-lg transition-colors w-full"
          >
            清空结果
          </button>
        </div>
      </div>
    </div>
  )
}

export default Statistics
