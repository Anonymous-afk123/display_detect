import cv2
import numpy as np
from PIL import Image

class ImageProcessor:
    def __init__(self):
        """
        初始化图像处理器
        """
        pass
    
    def pil_to_cv2(self, image):
        """
        将PIL图像转换为CV2格式
        :param image: PIL图像
        :return: CV2图像
        """
        if hasattr(image, 'convert'):
            return cv2.cvtColor(np.array(image), cv2.COLOR_RGB2BGR)
        return image
    
    def cv2_to_pil(self, image):
        """
        将CV2图像转换为PIL格式
        :param image: CV2图像
        :return: PIL图像
        """
        if len(image.shape) == 3:
            return Image.fromarray(cv2.cvtColor(image, cv2.COLOR_BGR2RGB))
        return Image.fromarray(image)
    
    def preprocess_image(self, image):
        """
        预处理图像
        :param image: 输入图像
        :return: 预处理后的图像
        """
        # 这里可以添加预处理步骤，如调整大小、归一化等
        return image
    
    def draw_detections(self, image, results):
        """
        绘制检测结果
        :param image: 原始图像
        :param results: 检测结果
        :return: 标注后的图像
        """
        # 使用YOLO的内置绘制功能
        return results[0].plot()
