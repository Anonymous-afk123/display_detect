from fastapi import APIRouter, UploadFile, File, Form, HTTPException
from fastapi.responses import JSONResponse
from app.models.model_loader import DisplayDefectDetector
from app.utils.image_processor import ImageProcessor
import base64
import io
from PIL import Image
import numpy as np

router = APIRouter()
detector = DisplayDefectDetector()
image_processor = ImageProcessor()

@router.post("/detect")
async def detect_image(
    file: UploadFile = File(...),
    confidence: float = Form(0.25)
):
    try:
        # 读取图像文件
        contents = await file.read()
        image = Image.open(io.BytesIO(contents))
        
        # 检测图像
        result = detector.detect_image(image, conf=confidence)
        
        # 处理检测结果
        annotated_image = result["annotated_image"]
        analysis_result = result["analysis_result"]
        
        # 将标注图像转换为 base64
        annotated_pil = image_processor.cv2_to_pil(annotated_image)
        buffered = io.BytesIO()
        annotated_pil.save(buffered, format="JPEG")
        img_str = base64.b64encode(buffered.getvalue()).decode("utf-8")
        
        # 构建响应
        response = {
            "annotated_image": f"data:image/jpeg;base64,{img_str}",
            "analysis_result": {
                "num_defects": analysis_result["num_defects"],
                "is_qualified": analysis_result["is_qualified"],
                "severity": analysis_result["severity"],
                "defects": analysis_result.get("defects", [])
            }
        }
        
        return JSONResponse(content=response)
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"检测失败: {str(e)}")

@router.get("/statistics")
async def get_statistics():
    try:
        stats = detector.get_statistics()
        return JSONResponse(content=stats)
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"获取统计信息失败: {str(e)}")

@router.post("/clear-results")
async def clear_results():
    try:
        success = detector.clear_results()
        return JSONResponse(content={"success": success, "message": "已清空所有检测结果" if success else "清空失败"})
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"清空结果失败: {str(e)}")

@router.get("/model-info")
async def get_model_info():
    try:
        info = detector.get_model_info()
        return JSONResponse(content=info)
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"获取模型信息失败: {str(e)}")
