from ultralytics import YOLO
import os

class DisplayDefectDetector:
    def __init__(self, model_path="yolov8s.pt"):
        """
        初始化显示屏缺陷检测器
        :param model_path: 模型路径
        """
        self.model_path = model_path
        self.model = None
        self.load_model()
        
    def load_model(self):
        """
        加载YOLOv8模型
        """
        try:
            if not os.path.exists(self.model_path):
                print(f"模型文件 {self.model_path} 不存在，正在自动下载...")
            self.model = YOLO(self.model_path)
            print(f"模型 {self.model_path} 加载成功！")
        except Exception as e:
            print(f"模型加载失败: {e}")
            raise
    
    def detect_image(self, image, conf=0.25):
        """
        检测图像中的缺陷
        :param image: 输入图像 (PIL或CV2格式)
        :param conf: 置信度阈值
        :return: 检测结果
        """
        try:
            import numpy as np
            
            # 处理图像格式
            if hasattr(image, 'convert'):
                # PIL图像，转换为RGB（去除Alpha通道）
                image = image.convert('RGB')
                image = np.array(image)
            
            # 确保图像是3通道
            if len(image.shape) == 2:
                # 灰度图转换为RGB
                image = np.stack([image] * 3, axis=-1)
            elif image.shape[2] == 4:
                # RGBA转换为RGB
                image = image[:, :, :3]
            
            # 模型预测
            results = self.model.predict(image, conf=conf)
            
            # 分析结果
            num_defects = len(results[0].boxes)
            is_qualified = num_defects == 0
            severity = min(num_defects, 5)
            
            # 绘制检测结果
            annotated_image = results[0].plot()
            
            # 构建缺陷列表
            defects = []
            for box in results[0].boxes:
                defect = {
                    "type": "defect",  # 简化处理，实际可以根据类别ID映射
                    "confidence": float(box.conf[0]),
                    "coordinates": box.xyxy[0].tolist()
                }
                defects.append(defect)
            
            analysis_result = {
                "num_defects": num_defects,
                "is_qualified": is_qualified,
                "severity": severity,
                "defects": defects
            }
            
            return {
                "annotated_image": annotated_image,
                "analysis_result": analysis_result
            }
        except Exception as e:
            print(f"检测失败: {e}")
            raise
    
    def get_statistics(self):
        """
        获取统计信息
        :return: 统计信息
        """
        # 简化实现，实际应该从存储中获取
        return {
            "total_detections": 0,
            "qualified": 0,
            "unqualified": 0,
            "avg_defects": 0.0
        }
    
    def clear_results(self):
        """
        清空所有检测结果
        :return: 清空成功与否
        """
        # 简化实现
        return True
    
    def get_model_info(self):
        """
        获取模型信息
        :return: 模型信息
        """
        if self.model is None:
            return {"status": "未加载"}
        
        return {
            "status": "已加载",
            "model_path": self.model_path,
            "model_name": self.model_path.split("/")[-1]
        }
